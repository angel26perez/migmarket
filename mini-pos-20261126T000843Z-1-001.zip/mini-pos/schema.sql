DROP TABLE IF EXISTS detalle_venta;
DROP TABLE IF EXISTS ventas;
DROP TABLE IF EXISTS productos;

CREATE TABLE productos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nombre TEXT NOT NULL,
    precio REAL NOT NULL,
    stock INTEGER NOT NULL,
    categoria TEXT NOT NULL,
    etiqueta TEXT DEFAULT '', -- Ej: '2x1', 'Rebaja', 'Más Vendido'
    imagen TEXT
);

CREATE TABLE ventas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    total REAL NOT NULL,
    fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE detalle_venta (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    venta_id INTEGER,
    producto_id INTEGER,
    cantidad INTEGER,
    subtotal REAL,
    FOREIGN KEY (venta_id) REFERENCES ventas (id),
    FOREIGN KEY (producto_id) REFERENCES productos (id)
);

-- Datos con categorías y ofertas
INSERT INTO productos (nombre, precio, stock, categoria, etiqueta, imagen) VALUES 
('Café Americano', 4500.0, 20, 'Bebidas', 'Rebaja', '☕'),
('Pan de Bono', 3000.0, 15, 'Panadería', '2x1', '🍞'),
('Jugo Natural', 6000.0, 10, 'Bebidas', 'Más Vendido', '🧃'),
('Sandwich Pollo', 12000.0, 8, 'Comidas', 'Más Vendido', '🥪'),
('Té Verde', 4000.0, 12, 'Bebidas', '', '🍵'),
('Galletas de Chocolate', 2500.0, 25, 'Snacks', 'Rebaja', '🍪'),
('Ensalada César', 15000.0, 5, 'Comidas', 'Más Vendido', '🥗'),
('Smoothie de Fresa', 8000.0, 7, 'Bebidas', '2x1', '🍓'),
('Croissant de Mantequilla', 3500.0, 18, 'Panadería', '', '🥐'),
('Agua Mineral', 2000.0, 30, 'Bebidas', 'Más Vendido', '💧');