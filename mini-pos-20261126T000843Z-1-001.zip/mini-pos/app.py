import os
import sqlite3
from flask import Flask, g, jsonify, render_template, request

app = Flask(__name__)
DATABASE = "database.db"


def get_db():
  db = getattr(g, "_database", None)
  if db is None:
    db = g._database = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
  return db


@app.teardown_appcontext
def close_connection(exception):
  db = getattr(g, "_database", None)
  if db is not None:
    db.close()


def init_db():
  with app.app_context():
    db = get_db()
    db.executescript("""
            DROP TABLE IF EXISTS detalle_venta;
            DROP TABLE IF EXISTS ventas;
            DROP TABLE IF EXISTS productos;

            CREATE TABLE productos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nombre TEXT NOT NULL,
                precio REAL NOT NULL,
                stock INTEGER NOT NULL,
                categoria TEXT NOT NULL,
                etiqueta TEXT DEFAULT '',
                imagen TEXT
            );

            CREATE TABLE ventas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                total REAL NOT NULL,
                fecha TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE detalle_venta (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                venta_id INTEGER,
                producto_id INTEGER,
                cantidad INTEGER,
                subtotal REAL,
                FOREIGN KEY (venta_id) REFERENCES ventas (id),
                FOREIGN KEY (producto_id) REFERENCES productos (id)
            );
        """)

    catalogo_real = {
        "Bebidas": [
            ("Café Americano", "☕", 4500),
            ("Jugo Natural de Naranja", "🧃", 6000),
            ("Té Verde Helado", "🍵", 4000),
            ("Agua Mineral con Gas", "💧", 2500),
            ("Smoothie de Fresa", "🍓", 8000),
            ("Cerveza Artesanal", "🍺", 12000),
            ("Vino Tinto Reserva", "🍷", 25000),
            ("Refresco de Cola", "🥤", 5000),
            ("Chocolate Caliente", "🍫", 5500),
            ("Limonada de Coco", "🥥", 7000),
        ],
        "Panadería": [
            ("Pan de Bono Tradicional", "🍞", 3000),
            ("Croissant de Mantequilla", "🥐", 3500),
            ("Pan Baguette Rústico", "🥖", 4000),
            ("Pretzel Suizo", "🥨", 4500),
            ("Panquecas con Miel", "🥞", 9000),
            ("Waffle Belga", "🧇", 9500),
            ("Muffin de Arándanos", "🧁", 4000),
            ("Dona de Chocolate", "🍩", 3000),
            ("Pan Integral", "🍞", 5000),
            ("Almojábana Costeña", "🧀", 3500),
        ],
        "Comidas": [
            ("Sandwich de Pollo", "🥪", 12000),
            ("Pizza Margarita Familiar", "🍕", 28000),
            ("Hamburguesa Doble Carne", "🍔", 18000),
            ("Ensalada César con Pollo", "🥗", 15000),
            ("Tacos Mexicanos (3 Und)", "🌮", 16000),
            ("Burrito Mixto", "🌯", 14000),
            ("Perro Caliente Especial", "🌭", 10000),
            ("Sopa de Verduras del Día", "🍲", 7000),
            ("Ceviche de Camarón", "🦐", 22000),
            ("Plato Típico Ejecutivo", "🍛", 17000),
        ],
        "Snacks": [
            ("Galletas de Chocolate", "🍪", 2500),
            ("Barra de Cacao Oscuro", "🍫", 4000),
            ("Caramelos Surtidos", "🍬", 1500),
            ("Paleta Dulce", "🍭", 1000),
            ("Crispetas de Maíz Mantequilla", "🍿", 5000),
            ("Maní Salado", "🥜", 3000),
            ("Galletas Integrales", "🍘", 3500),
            ("Helado de Vainilla", "🍧", 6000),
            ("Papas Fritas de Bolsa", "🍟", 3500),
            ("Chocolatina de Leche", "🍫", 4500),
        ],
        "Frutas y Verduras": [
            ("Manzana Roja Fresca", "🍎", 2000),
            ("Banano Maduro (Kilo)", "🍌", 3500),
            ("Uvas Verdes sin Semilla", "🍇", 7000),
            ("Fresas Seleccionadas", "🍓", 8000),
            ("Piña Miel Entera", "🍍", 6000),
            ("Aguacate Hass", "🥑", 4500),
            ("Tomate Río Grande", "🍅", 3000),
            ("Zanahoria Fresca", "🥕", 2500),
            ("Lechuga Crespa", "🥬", 2800),
            ("Limón Tahití", "🍋", 2000),
        ],
        "Aseo": [
            ("Jabón de Baño Antibacterial", "🧼", 3500),
            ("Esponja de Cocina Doble Uso", "🧽", 2000),
            ("Crema Corporal Hidratante", "🧴", 12000),
            ("Papel Higiénico (Pack x4)", "🧻", 9000),
            ("Escoba Cerdas Suaves", "🧹", 14000),
            ("Bloqueador Solar", "🧴", 25000),
            ("Desodorante Roll-On", "🧴", 9500),
            ("Limpiavidrios Spray", "🪟", 7000),
            ("Detergente en Polvo (1kg)", "🧺", 11000),
            ("Cloro Desinfectante", "🧴", 6000),
        ],
        "Lácteos": [
            ("Queso Doble Crema (Bloque)", "🧀", 12000),
            ("Leche Entera Deslactosada (Litro)", "🥛", 4500),
            ("Mantequilla con Sal", "🧈", 5000),
            ("Helado Cremoso de Fresa", "🍦", 8500),
            ("Yogur Griego Natural", "🍼", 6500),
            ("Queso Mozzarella", "🧀", 13000),
            ("Crema de Leche", "🥛", 5500),
            ("Leche Condensada", "🍮", 6000),
            ("Queso Costeño", "🧀", 10000),
            ("Arequipe Tradicional", "🍯", 7000),
        ],
    }

    cursor = db.cursor()
    contador_reba = 0

    for categoria, lista_items in catalogo_real.items():
      for ronda in range(1, 6):
        for idx, (nombre_base, emoji, precio_base) in enumerate(lista_items):
          sufijo = (
              "Clásico"
              if ronda == 1
              else (
                  "Familiar"
                  if ronda == 2
                  else (
                      "Especial"
                      if ronda == 3
                      else "Artesanal" if ronda == 4 else "Premium"
                  )
              )
          )
          nombre_final = f"{nombre_base} {sufijo}"
          precio_final = float(precio_base + (ronda * 300) - 200)
          stock_final = (idx * 4 + ronda) % 25 + 5

          # Asignamos la etiqueta 'Rebaja' estrictamente a los primeros 10 productos creados
          etiqueta_final = ""
          if contador_reba < 10:
            etiqueta_final = "Rebaja"
            contador_reba += 1

          cursor.execute(
              "INSERT INTO productos (nombre, precio, stock, categoria,"
              " etiqueta, imagen) VALUES (?, ?, ?, ?, ?, ?)",
              (
                  nombre_final,
                  precio_final,
                  stock_final,
                  categoria,
                  etiqueta_final,
                  emoji,
              ),
          )

    db.commit()


@app.route("/")
def index():
  return render_template("index.html")


@app.route("/api/productos", methods=["GET"])
def get_productos():
  db = get_db()
  cursor = db.execute("SELECT * FROM productos")
  productos = [dict(row) for row in cursor.fetchall()]
  return jsonify(productos)


@app.route("/api/ventas", methods=["GET"])
def get_ventas():
  db = get_db()
  cursor = db.execute("SELECT * FROM ventas ORDER BY fecha DESC")
  ventas = [dict(row) for row in cursor.fetchall()]
  return jsonify(ventas)


@app.route("/api/checkout", methods=["POST"])
def checkout():
  data = request.get_json()
  carrito = data.get("carrito", [])
  if not carrito:
    return jsonify({"error": "El carrito está vacío"}), 400

  db = get_db()
  cursor = db.cursor()

  try:
    total_venta = 0
    for item in carrito:
      prod_id = item["id"]
      cant = item["cantidad"]
      cursor.execute("SELECT precio, stock FROM productos WHERE id = ?", (prod_id,))
      prod = cursor.fetchone()
      if not prod or prod["stock"] < cant:
        return jsonify({"error": f"Stock insuficiente para ID {prod_id}"}), 400
      total_venta += prod["precio"] * cant

    cursor.execute("INSERT INTO ventas (total) VALUES (?)", (total_venta,))
    venta_id = cursor.lastrowid

    for item in carrito:
      prod_id = item["id"]
      cant = item["cantidad"]
      cursor.execute("SELECT precio FROM productos WHERE id = ?", (prod_id,))
      precio = cursor.fetchone()["precio"]
      subtotal = precio * cant
      cursor.execute(
          "INSERT INTO detalle_venta (venta_id, producto_id, cantidad,"
          " subtotal) VALUES (?, ?, ?, ?)",
          (venta_id, prod_id, cant, subtotal),
      )
      cursor.execute(
          "UPDATE productos SET stock = stock - ? WHERE id = ?", (cant, prod_id)
      )

    db.commit()
    return jsonify({"success": True, "venta_id": venta_id, "total": total_venta})
  except Exception as e:
    db.rollback()
    return jsonify({"error": str(e)}), 500


if __name__ == "__main__":
  if not os.path.exists(DATABASE):
    init_db()
  app.run(debug=True, port=5000)