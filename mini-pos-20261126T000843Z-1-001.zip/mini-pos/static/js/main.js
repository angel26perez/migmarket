let productosCatalogo = [];
let carrito = [];
let categoriaActual = 'Todos';

document.addEventListener("DOMContentLoaded", () => {
    cargarProductos();
});

async function cargarProductos() {
    try {
        const response = await fetch('/api/productos');
        productosCatalogo = await response.json();
        actualizarVistaCompleta();
    } catch (error) {
        console.error("Error cargando productos:", error);
    }
}

function actualizarVistaCompleta() {
    renderizarOfertas(productosCatalogo);
    renderizarPopulares(productosCatalogo);
    filtrarPorCategoria(categoriaActual);
}

function renderizarOfertas(lista) {
    const grid = document.getElementById('grid-ofertas');
    if (!grid) return;
    // Solo muestra exactamente los productos con etiqueta 'Rebaja'
    const ofertas = lista.filter(p => p.etiqueta === 'Rebaja');
    grid.innerHTML = '';
    if (ofertas.length === 0) {
        grid.innerHTML = `<p style="color: #888; font-size: 0.9rem;">No hay rebajas disponibles.</p>`;
        return;
    }
    ofertas.forEach(prod => grid.appendChild(crearTarjeta(prod)));
}

function renderizarPopulares(lista) {
    const grid = document.getElementById('grid-populares');
    if (!grid) return;
    // Selecciona los primeros 6 productos como populares comunes
    const populares = lista.slice(0, 6);
    grid.innerHTML = '';
    populares.forEach(prod => grid.appendChild(crearTarjeta(prod)));
}

function filtrarPorCategoria(categoria) {
    categoriaActual = categoria;
    let catBusqueda = (categoria === 'Aseo Hogar') ? 'Aseo' : categoria;

    const titulo = document.getElementById('titulo-categoria-activa');
    if (titulo) titulo.innerText = `📂 Productos de la Categoría: ${categoria}`;

    const grid = document.getElementById('grid-categorias');
    if (!grid) return;
    grid.innerHTML = '';

    const filtrados = (catBusqueda === 'Todos')
        ? productosCatalogo 
        : productosCatalogo.filter(p => p.categoria.toLowerCase() === catBusqueda.toLowerCase());

    filtrados.forEach(prod => grid.appendChild(crearTarjeta(prod)));
}

function filtrarProductos() {
    const texto = document.getElementById('search-input').value.toLowerCase().trim();
    const gridCategorias = document.getElementById('grid-categorias');
    const tituloCategoria = document.getElementById('titulo-categoria-activa');

    if (!texto) {
        actualizarVistaCompleta();
        if (tituloCategoria) tituloCategoria.innerText = `📂 Productos de la Categoría: ${categoriaActual}`;
        return;
    }

    const filtrados = productosCatalogo.filter(prod => 
        prod.nombre.toLowerCase().includes(texto) || prod.id.toString() === texto || prod.id.toString().includes(texto)
    );

    renderizarOfertas(filtrados);
    renderizarPopulares(filtrados);

    if (gridCategorias) {
        gridCategorias.innerHTML = '';
        filtrados.forEach(prod => gridCategorias.appendChild(crearTarjeta(prod)));
    }
    if (tituloCategoria) tituloCategoria.innerText = `🔍 Resultados de búsqueda para: "${texto}"`;
}

function crearTarjeta(prod) {
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
        <span class="product-id">ID: #${prod.id}</span>
        ${prod.etiqueta ? `<span class="product-badge">${prod.etiqueta}</span>` : ''}
        <div class="product-icon">${prod.imagen || '📦'}</div>
        <h3>${prod.nombre}</h3>
        <p>$${prod.precio.toLocaleString()} | Stock: ${prod.stock}</p>
        <button class="btn-add" onclick="agregarAlCarrito(${prod.id})">Agregar</button>
    `;
    return card;
}

function agregarAlCarrito(id) {
    const producto = productosCatalogo.find(p => p.id === id);
    const itemEnCarrito = carrito.find(item => item.id === id);

    if (itemEnCarrito) {
        if (itemEnCarrito.cantidad < producto.stock) {
            itemEnCarrito.cantidad++;
        } else {
            alert("No hay más stock disponible de este producto.");
            return;
        }
    } else {
        if (producto.stock > 0) {
            carrito.push({ id: producto.id, nombre: producto.nombre, precio: producto.precio, cantidad: 1 });
        } else {
            alert("Producto agotado.");
            return;
        }
    }
    renderizarCarrito();
}

function restarDelCarrito(id) {
    const item = carrito.find(p => p.id === id);
    if (item) {
        item.cantidad--;
        if (item.cantidad <= 0) {
            carrito = carrito.filter(p => p.id !== id);
        }
    }
    renderizarCarrito();
}

function eliminarDelCarrito(id) {
    carrito = carrito.filter(p => p.id !== id);
    renderizarCarrito();
}

function cancelarPedidoTotal() {
    if (carrito.length === 0) return;
    if (confirm("¿Estás seguro de que deseas cancelar todo el pedido?")) {
        carrito = [];
        renderizarCarrito();
    }
}

function renderizarCarrito() {
    const container = document.getElementById('cart-items');
    const totalElement = document.getElementById('cart-total');
    
    if (carrito.length === 0) {
        container.innerHTML = `<p style="color: #999; text-align: center; margin-top: 2rem;">El carrito está vacío</p>`;
        totalElement.innerText = `$0.0`;
        return;
    }

    container.innerHTML = '';
    let total = 0;

    carrito.forEach(item => {
        let subtotal = item.precio * item.cantidad;
        total += subtotal;

        const div = document.createElement('div');
        div.className = 'cart-item';
        div.innerHTML = `
            <div>
                <strong>${item.nombre}</strong><br>
                <div class="qty-controls">
                    <button class="btn-qty" onclick="restarDelCarrito(${item.id})">-</button>
                    <span>${item.cantidad}</span>
                    <button class="btn-qty" onclick="agregarAlCarrito(${item.id})">+</button>
                    <small style="margin-left:5px;">x $${item.precio.toLocaleString()}</small>
                </div>
            </div>
            <div>
                <span>$${subtotal.toLocaleString()}</span>
                <button style="border:none; background:none; cursor:pointer; margin-left:5px;" onclick="eliminarDelCarrito(${item.id})">❌</button>
            </div>
        `;
        container.appendChild(div);
    });

    totalElement.innerText = `$${total.toLocaleString()}`;
}

async function procesarPago() {
    if (carrito.length === 0) {
        alert("Agrega productos al carrito antes de cobrar.");
        return;
    }

    const payload = { carrito: carrito.map(item => ({ id: item.id, cantidad: item.cantidad })) };

    try {
        const response = await fetch('/api/checkout', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });

        const resultado = await response.json();

        if (response.ok) {
            mostrarFactura(resultado.venta_id, resultado.total, carrito);
            carrito = [];
            renderizarCarrito();
            cargarProductos();
        } else {
            alert(`Error: ${resultado.error}`);
        }
    } catch (error) {
        console.error("Error en la transacción:", error);
    }
}

function mostrarFactura(ventaId, total, itemsComprados) {
    document.getElementById('factura-id').innerText = `#${ventaId}`;
    document.getElementById('factura-fecha').innerText = new Date().toLocaleString();
    
    const detallesContainer = document.getElementById('factura-detalles');
    detallesContainer.innerHTML = '';

    itemsComprados.forEach(item => {
        const row = document.createElement('div');
        row.style.display = 'flex';
        row.style.justifyContent = 'space-between';
        row.style.fontSize = '0.9rem';
        row.style.margin = '0.3rem 0';
        row.innerHTML = `<span>${item.nombre} (x${item.cantidad})</span> <span>$${(item.precio * item.cantidad).toLocaleString()}</span>`;
        detallesContainer.appendChild(row);
    });

    document.getElementById('factura-total').innerText = `$${total.toLocaleString()}`;
    document.getElementById('modal-factura').style.display = 'flex';
}

function cerrarFactura() {
    document.getElementById('modal-factura').style.display = 'none';
}

async function abrirHistorial() {
    try {
        const res = await fetch('/api/ventas');
        const ventas = await res.json();
        const lista = document.getElementById('historial-lista');
        lista.innerHTML = '';

        if (ventas.length === 0) {
            lista.innerHTML = '<p>No hay ventas registradas aún.</p>';
        } else {
            ventas.forEach(v => {
                const item = document.createElement('div');
                item.style.padding = '0.5rem';
                item.style.borderBottom = '1px solid #ddd';
                item.innerHTML = `<strong>Venta #${v.id}</strong> - Total: $${v.total.toLocaleString()} <br><small>Fecha: ${v.fecha}</small>`;
                lista.appendChild(item);
            });
        }
        document.getElementById('modal-historial').style.display = 'flex';
    } catch (e) {
        console.error(e);
    }
}

function cerrarHistorial() {
    document.getElementById('modal-historial').style.display = 'none';
}